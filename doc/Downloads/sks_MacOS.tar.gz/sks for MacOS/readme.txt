Installation of sks on Mac OS
1. Install apache-tomcat server
2. Deploy sks.war into apache-tomcat 
3. Copy sks folder to /Applications/sks
4. Link the system sort and join to /Applications/sks/bin/sort and /Applications/sks/bin/join (ex. ln -s /usr/bin/join /Applications/sks/bin/join), then you will have two linked files :/Applications/sks/bin/sort and /Applications/sks/bin/join
5. Go to Broswer, http://localhost:8080/sks/ when is shows Spatial Keyword Service (SKS), the installztion is sucessful


Use of SKS service
To use the Spatial Keyword Search Service, we need build index for source data first. To load a dataset, use http://sks.cs.fiu.edu/sks/load and set category, dataset and header. For example:
http://localhost:8080/sks/load?category=auto-projects&dataset=http://n0.cs.fiu.edu/TFoverlays/auto-projects.asc&header=http://n0.cs.fiu.edu/TFoverlays/auto-projects.asc.header

and use http://sks.cs.fiu.edu/sks/status to check the loading status, for example:
http://localhost:8080/sks/status?category=auto-projects&refresh=2

And then, we can query. To query a dataset, use http://sks.cs.fiu.edu/sks/query and set parameters. For example:
http://localhost:8080/sks/query?category=auto-projects&x1=-80.298698&y1=25.702000&tfaction=tabview&timeout=6&d=9999999&numfind=20&header=1