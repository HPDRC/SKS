Installation of sks on Windows
1. Install java JRE, you can download it at http://www.oracle.com/technetwork/java/javase/downloads/java-se-jre-7-download-432155.html
2. Install apache-tomcat server
3. Deploy sks.war into apache-tomcat 
4. Copy the "sks" directory to c:\ (Then, you will have the directory of  C:\sks\bin, C:\sks\dat ...).
5. Go to Broswer, http://localhost:8080/sks/ when is shows Spatial Keyword Service (SKS), the installztion is sucessful


Use of SKS service
To use the Spatial Keyword Search Service, we need build index for source data first. To load a dataset, use http://sks.cs.fiu.edu/sks/load and set category, dataset and header. For example:
http://localhost:8080/sks/load?category=airport&dataset=http://cake.fiu.edu/OpenSKS/Datasets/airport.asc&header=http://cake.fiu.edu/OpenSKS/Datasets/airport.asc.header

and use http://sks.cs.fiu.edu/sks/status to check the loading status, for example:
http://localhost:8080/sks/status?category=airport

And then, we can query. To query a dataset, use http://sks.cs.fiu.edu/sks/query and set parameters. For example:
http://localhost:8080/sks/query?category=airport&x1=-80.298698&y1=25.702000&tfaction=tabview&timeout=6&d=9999999&numfind=20&header=1